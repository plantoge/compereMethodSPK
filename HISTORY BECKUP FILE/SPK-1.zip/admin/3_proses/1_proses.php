<div class="show">
	<div class="judul">
		<h3>Hasil Proses MFEP SAW</h3>
	</div>
	<div class="button">
		<a href="?hl=user&op=input">
			<button>
				<i class="fa fa-gavel" aria-hidden="true"></i>
			</button>
		</a>
	</div>

	<div class="form">
		<form method="post">
			<table class="w100 border" border="1">
				<tr>
					<th>No.</th>
					<th>No.</th>
					<th>No.</th>
					<th>No.</th>
				</tr>
				<?php ?>
				<tr>
					<td>a</td>
					<td>a</td>
					<td>a</td>
					<td>a</td>
				</tr>
				<?php ?>
			</table>
		</form>
	</div>
</div>