			<?php 
				for($i=1; $i <= 5; $i++) {
			?>
					<tr>
						<td>
							<input type="text" name="nilai_f<?= $i; ?>" placeholder="">
						</td>
					</tr>
			<?php 
				}
			?>