<?php 
/*==============================================================================================*/
/*|											KONEKSI DATABASE 									*/
/*==============================================================================================*/ 
// KONEKSI
// $localhost = "localhost";
// $username = "skrj3885_fauzi";
// $password = "Skripfauzi14";
// $nmdb = "skrj3885_db_spk";

// $db = mysqli_connect($localhost , $username , $password, $nmdb);
$db = mysqli_connect("localhost","root","","db_spk");

/*==============================================================================================*/
/*|										FUNCTION ALL IN ONE										*/
/*==============================================================================================*/ 
//FUNGSI TAMPIL DATA / SHOW DATA
function tampilkan_looping($sql) {
	global $db;
	$result = mysqli_query($db, $sql);
	$rows = [];

	while ( $row = mysqli_fetch_assoc($result) ) {
		$rows[] = $row;
	}
	return $rows;
}

function tampilkan_nonlooping($sql){
	global $db;
	$hasilsql = mysqli_query($db, $sql) or die($db -> error);
	$result = mysqli_fetch_assoc($hasilsql);
	return $result;
}

/*==============================================================================================*/
/*|												  USER											*/
/*==============================================================================================*/ 
//--------------------PROSES INPUT USER
function tambah_user($dtpost){
	global $db;
	$username = $dtpost["username"];
	$password1 = mysqli_real_escape_string($db, $dtpost["password1"] );
	$password2 = mysqli_real_escape_string($db, $dtpost["password2"] );
	$level = $dtpost["level"];
	// fungsi mysqli_real_escape_string = user bisa masukkan passwd dengan karakter kutip 1 dengan aman.

	// var_dump($dtpost);

	//koding cek password apa sama dengan password konfirmasi
	if ($password1 !== $password2) {
		?> 
		<script>
			alert("Konfirmasi Password Tidak Sesuai! Mohon Diulang.");
		</script>
		<?php 
		return 0;
	}

	//ENKRIPSI PASSWORD DENGAN PASSWORD_DEFAULT
	//PASSWORD_DEFAULT MERUPAKAN TEKNIK ALGORITMA UNTUK ENKRIPSI PASSWORD DI PHP5
	//TIAP PHP UPDATE MAKA TEKNIK ALGORITMA ENKRIPSI JUGA AKAN DI UPDATE YG TERBARU
	$password_enkripsi = password_hash($password1, PASSWORD_DEFAULT);
	// echo $password_enkripsi;
	// die;
	//TAMBAHKAN DATA REGISTRASI KE TABLE USER
	$sqlregistrasi = "INSERT INTO user (username,password,level) VALUES('$username','$password_enkripsi','$level')";
	mysqli_query($db, $sqlregistrasi) or die($db -> error);
	return mysqli_affected_rows($db);
}	

//--------------------PROSES EDIT USER
function edit_user($dtpost){
	global $db;
	$get_id = $dtpost["get_id"];
	$username = $dtpost["username"];
	$password1 = mysqli_real_escape_string($db, $dtpost["password1"] );
	$password2 = mysqli_real_escape_string($db, $dtpost["password2"] );
	$level = $dtpost["level"];
	// fungsi mysqli_real_escape_string = user bisa masukkan passwd dengan karakter kutip 1 dengan aman.

	// var_dump($dtpost);
	// die;

	//koding cek password apa sama dengan password konfirmasi
	if ($password1 !== $password2) {
		?> 
		<script>
			alert("Konfirmasi Password Tidak Sesuai! Mohon Diulang.");
		</script>
		<?php 
		return 0;
	}

	//ENKRIPSI PASSWORD DENGAN PASSWORD_DEFAULT
	//PASSWORD_DEFAULT MERUPAKAN TEKNIK ALGORITMA UNTUK ENKRIPSI PASSWORD DI PHP5
	//TIAP PHP UPDATE MAKA TEKNIK ALGORITMA ENKRIPSI JUGA AKAN DI UPDATE YG TERBARU
	$password_enkripsi = password_hash($password1, PASSWORD_DEFAULT);
	// echo $password_enkripsi;
	// die;
	//TAMBAHKAN DATA REGISTRASI KE TABLE USER
	$sqlregistrasi = "UPDATE user SET username='$username', password = '$password_enkripsi' WHERE id = '$get_id'";
	mysqli_query($db, $sqlregistrasi) or die($db -> error);
	return mysqli_affected_rows($db);
}	

/*==============================================================================================*/
/*|											  FAKTOR											*/
/*==============================================================================================*/ 
//--------------------PROSES TAMBAH FAKTOR
function tambah_faktor($dtpost){
	global$db;

	$nama_faktor = $dtpost["nama_faktor"];
	$inisial = $dtpost["inisial"];
	$nbf = $dtpost["nbf"];
	$jenis_faktor = $dtpost["jenis_faktor"];

	// var_dump($dtpost);
	// die;
	$query_f1_faktor ="INSERT INTO f1_faktor (nama_faktor, inisial, jenis_faktor,nbf) VALUES ('$nama_faktor', '$inisial','$jenis_faktor','$nbf')";
	
	mysqli_query($db, $query_f1_faktor) or die ( $db -> error);

	return mysqli_affected_rows($db);
}

//--------------------PROSES EDIT FAKTOR
function edit_faktor($dtpost){
	global$db;

	$get_id = $dtpost["id_faktor"];
	$nama_faktor = $dtpost["nama_faktor"];
	$jenis_faktor = $dtpost["jenis_faktor"];
	$nbf = $dtpost["nbf"];

	// var_dump($dtpost);
	// die;
	$query_f1_faktor ="UPDATE f1_faktor SET nama_faktor='$nama_faktor', jenis_faktor='$jenis_faktor', nbf = '$nbf' WHERE id_faktor = '$get_id'";
	
	mysqli_query($db, $query_f1_faktor) or die ( $db -> error);

		return mysqli_affected_rows($db);
}

/*==============================================================================================*/
/*|										 EVALUASI FAKTOR										*/
/*==============================================================================================*/ 
//--------------------PROSES TAMBAH EVALUASI FAKTOR
function tambah_ef($dtpost) {
	global $db;
	
	$jml_dt = $dtpost["jml_dt"];
	$nisn = $dtpost["nisn"];
	$nama_siswa = $dtpost["nama_siswa"];
	$nilai_f1 = $dtpost["nilai_f1"];
	$nilai_f2 = $dtpost["nilai_f2"];
	$nilai_f3 = $dtpost["nilai_f3"];
	$nilai_f4 = $dtpost["nilai_f4"];
	$nilai_f5 = $dtpost["nilai_f5"];

	// echo $jml_dt;
	// var_dump($dtpost);
	// die;
	
	$sql ="INSERT INTO f2_evaluasi (nisn, nama_siswa, nilai_f1, nilai_f2, nilai_f3, nilai_f4, nilai_f5) VALUES ";
		
	for( $i=0; $i < $jml_dt; $i++ ){
		$sql .= "('$nisn[$i]','$nama_siswa[$i]','$nilai_f1[$i]','$nilai_f2[$i]','$nilai_f3[$i]','$nilai_f4[$i]','$nilai_f5[$i]')";
		$sql .= ",";		
	}
	// rtrim adalah menghilangkan charakter dari kanan
	$sql = rtrim($sql,",");
	// echo $sql;
	// die;
	mysqli_query($db, $sql) or die ( $db -> error);

	return mysqli_affected_rows($db);
}
//--------------------PROSES EDIT EVALUASI FAKTOR
function edit_ef($dtpost) {
	global$db;

	$nisn = @$dtpost["nisn"];
	$nama_siswa = @$dtpost["nama_siswa"];
	$nilai_f1 = @$dtpost["nilai_f1"];
	$nilai_f2 = @$dtpost["nilai_f2"];
	$nilai_f3 = @$dtpost["nilai_f3"];
	$nilai_f4 = @$dtpost["nilai_f4"];
	$nilai_f5 = @$dtpost["nilai_f5"];
	// var_dump($dtpost);
	// die;
	$query_f2_evaluasi ="UPDATE f2_evaluasi SET nilai_f1='$nilai_f1', nilai_f2='$nilai_f2',nilai_f3='$nilai_f3',nilai_f4='$nilai_f4',nilai_f5='$nilai_f5' WHERE nisn = '$nisn'";
	
	mysqli_query($db, $query_f2_evaluasi) or die ( $db -> error);

	return mysqli_affected_rows($db);

}
?>