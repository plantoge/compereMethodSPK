CREATE TABLE f2_evaluasi (
	nisn varchar(9) PRIMARY KEY,
	nama_siswa varchar(50),
	nilai_f1 float,
	nilai_f2 float,
	nilai_f3 float,
	nilai_f4 float,
	nilai_f5 float
);