CREATE TABLE f3_hasil_saw (
	id_hsaw int AUTO_INCREMENT PRIMARY KEY,
    nisn varchar(9) NOT NULL,
    tne float
)