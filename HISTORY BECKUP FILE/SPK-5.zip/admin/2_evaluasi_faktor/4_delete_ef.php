<?php
	$get_nisn = $_GET["nisn"];
	$sql_del = " DELETE FROM f2_evaluasi WHERE nisn = '$get_nisn'; ";
	$result_user=mysqli_query($db, $sql_del) or die ($db -> error);
?>
<script type="text/javascript">
	window.location.href="?hl=ef&op=show";
</script>