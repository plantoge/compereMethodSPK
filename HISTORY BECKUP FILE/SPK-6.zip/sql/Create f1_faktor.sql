CREATE TABLE f1_faktor (
	inisial varchar(2) PRIMARY KEY,
	nama_faktor varchar(50),
	jenis_faktor enum('cost','benefit'),
	nbf float
);
