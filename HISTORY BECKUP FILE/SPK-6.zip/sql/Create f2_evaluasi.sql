CREATE TABLE f2_evaluasi (
	nisn varchar(9) PRIMARY KEY,
	nama_siswa varchar(50),
	nb_f1 float,
	nb_f2 float,
	nb_f3 float,
	nb_f4 float,
	nb_f5 float,
	ne_f1 float,
	ne_f2 float,
	ne_f3 float,
	ne_f4 float,
	ne_f5 float
);