CREATE TABLE f4_hasil_saw (
	id_hsaw int AUTO_INCREMENT PRIMARY KEY,
    nisn varchar(9) NOT NULL,
    FOREIGN KEY(nisn) REFERENCES f2_evaluasi(nisn),
    vi float
)