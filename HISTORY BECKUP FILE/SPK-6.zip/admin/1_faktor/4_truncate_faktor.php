<?php
$sql_del = "TRUNCATE TABLE f1_faktor;";

$result_fktr=mysqli_query($db, $sql_del) or die ($db -> error);
?>

<script type="text/javascript">
	window.location.href="?hl=fktr&op=show";
</script>