<?php 
$sql = "SELECT id_faktor, nama_faktor, inisial, jenis_faktor, nbf FROM f1_faktor;";
$user = tampilkan_looping($sql);

// var_dump($user);

// foreach ($user as $data) {
// 	echo $data["nama_faktor"];
// }
?>
<div class="show">
	<div class="judul">
		<h3>Data Faktor</h3>
		<h5 style="font-weight: normal; margin-top: -10px;">
			note : Data faktor atau Kriteria
		</h5>
	</div>
	<div class="button">
		<a href="?hl=fktr&op=show&target=inp">
			<button name="tambah">
				<i class="fa fa-plus" aria-hidden="true"></i>
			</button>
		</a>
		<div class="bg_faktor">
			<?php 
				$target = @$_GET["target"];

				if ($target == "inp") {	include "2_input_faktor.php"; } 
				elseif ($target == "edt"){ include "3_edit_faktor.php"; }
			?>
		</div>
	</div>

	<div class="form">
		
		<form method="post">
			<table class="w100 border" border="1" style="text-align: center;">
				<tr>
					<th>No.</th>
					<th>Inisial</th>
					<th>Nama Faktor</th>
					<th>Jenis Faktor</th>
					<th>NBF</th>
					<th colspan="2">Opsi</th>
				</tr>
				<?php $no = 1; ?>
				<?php foreach ($user as $data) : ?>
				<tr>
					<td><?= $no++; ?></td>
					<td><?= $data["inisial"]; ?></td>
					<td><?= $data["nama_faktor"]; ?></td>
					<td><?= $data["jenis_faktor"]; ?></td>
					<td><?= $data["nbf"]; ?></td>
					<td style="border-right: 0px;">
						<a href="?hl=fktr&op=show&target=edt&id=<?= $data["id_faktor"]; ?>">
							<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
						</a>
					</td>
					<td>
						<a href="?hl=fktr&op=delete&id=<?= $data["id_faktor"]; ?>" onclick="return confirm('Yakin Delete Data ? ')">
							<i class="fa fa-trash-o" aria-hidden="true"></i>
						</a>
					</td>
				</tr>
				<?php 
					$total_bobot = 0;
					$total_bobot = $total_bobot + $data["nbf"];
					// echo $total_bobot;
				?>
				<?php endforeach; ?>
			</table>
			<!-- TOMBOL UNTUK MENGKOSONG KAN TABEL ATAU TRUNCATE -->
			<div>
				<a href="?hl=fktr&op=trunc" onclick="return confirm('Yakin Kosongkan Data ? ')">
					<i class="fa fa-plus" aria-hidden="true"></i> Empty Tabel
				</a>
			</div>
		</form>
	</div>
</div>