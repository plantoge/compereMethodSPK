-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2018 at 09:20 AM
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_spk`
--

-- --------------------------------------------------------

--
-- Table structure for table `f1_faktor`
--

CREATE TABLE IF NOT EXISTS `f1_faktor` (
  `id_faktor` int(11) NOT NULL,
  `nama_faktor` varchar(50) DEFAULT NULL,
  `jenis_faktor` enum('cost','benefit') NOT NULL,
  `nbf` float DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `f1_faktor`
--

INSERT INTO `f1_faktor` (`id_faktor`, `nama_faktor`, `jenis_faktor`, `nbf`) VALUES
(25, 'Rata-rata nilai', 'cost', 0.2),
(26, 'Nilai sikap', 'cost', 0.3),
(27, 'Absensi', 'benefit', 0.15),
(28, 'Penghasilan orang tua', 'cost', 0.1),
(29, 'Jumlah kasus', 'benefit', 0.25);

-- --------------------------------------------------------

--
-- Table structure for table `f2_evaluasi`
--

CREATE TABLE IF NOT EXISTS `f2_evaluasi` (
  `nisn` varchar(9) NOT NULL,
  `nama_siswa` varchar(50) DEFAULT NULL,
  `nilai_f1` float DEFAULT NULL,
  `nilai_f2` float DEFAULT NULL,
  `nilai_f3` float DEFAULT NULL,
  `nilai_f4` float DEFAULT NULL,
  `nilai_f5` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `f2_evaluasi`
--

INSERT INTO `f2_evaluasi` (`nisn`, `nama_siswa`, `nilai_f1`, `nilai_f2`, `nilai_f3`, `nilai_f4`, `nilai_f5`) VALUES
('140751', 'Fauzi', 1, 2, 3, 4, 5),
('140753', 'fauzi3', 1, 2, 3, 4, 5),
('140754', 'fauzi4', 1, 2, 3, 4, 5);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(30) DEFAULT NULL,
  `password` varchar(500) DEFAULT NULL,
  `level` enum('guru','admin') DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `level`) VALUES
(1, 'fauzi', '$2y$10$hr9.4IPB89QhgrHXCgjO/eyBB7soPIgNeqxEh6CRc3zDQUsCSeGze', 'admin'),
(2, 'tio', '$2y$10$FHJI1uZ7MJyMsYRNUAZCm.9s15Ftrtz0vHQCuwHYiPC1p5NnYD9te', 'guru'),
(3, 'gege', '$2y$10$fdJq8wVxd4yRRUISNU4Fvu.SOfZ1FMpKdUMqVei/g8iTCnvHP..g6', 'guru'),
(6, 'ripal', '$2y$10$OzGTg9vG.1zwZrSKe6Ks2.N12KVHbEJEIYkfWgVYX2/3gFqgLMihm', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `f1_faktor`
--
ALTER TABLE `f1_faktor`
  ADD PRIMARY KEY (`id_faktor`);

--
-- Indexes for table `f2_evaluasi`
--
ALTER TABLE `f2_evaluasi`
  ADD PRIMARY KEY (`nisn`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `f1_faktor`
--
ALTER TABLE `f1_faktor`
  MODIFY `id_faktor` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=30;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
