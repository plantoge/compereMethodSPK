CREATE TABLE f1_faktor (
	id_faktor int AUTO_INCREMENT PRIMARY KEY,
	nama_faktor varchar(50),
	jenis_faktor enum('cost','benefit'),
	nbf float
);
