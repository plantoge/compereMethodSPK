<?php
$get_id = $_GET["id"];

$sql_del = " DELETE FROM f1_faktor WHERE id_faktor = '$get_id'; ";

$result_user=mysqli_query($db, $sql_del) or die ($db -> error);
?>

<script type="text/javascript">
	window.location.href="?hl=fktr&op=show";
</script>