<?php 
$get_id = $_GET["id"];
// echo $get_id;

$sql = "SELECT * FROM f1_faktor WHERE id_faktor = '$get_id'";
$query = mysqli_query($db, $sql) or die($db -> error);
$hasil_sql = mysqli_fetch_array($query);

$data = tampilkan_looping($sql);
// var_dump($hasil_sql);

	// LOGIKA PEMBATASAN PEMBERIAN NILAI BOBOT FAKTOR
	$sql2 = "SELECT nbf FROM f1_faktor;";
	$hasil2 = tampilkan_looping($sql2); 
	//var_dump($hasil2);

	$totalnbf = 0;
	$sisanbf = 0;
	foreach ($hasil2 as $data2) {
		$totalnbf = $totalnbf + $data2["nbf"];
	} 
	// echo $totalnbf;
	$sisanbf = 1 - $totalnbf;
?>
<div class="bg_faktor">
	<form method="post" class="col-66">
		<p class="note">Penambahan Nilai Bobot yang dibolehkan tinggal, <?= $sisanbf; ?></p>
		<table class="w100">
			<tr>
				<td class="w30">
					<input type="hidden" name="id_faktor" value="<?= $get_id; ?>">
					<input type="text" name="nama_faktor" value="<?= $data[0]["nama_faktor"]; ?>">
				</td>
				<td class="w30">
					<input type="text" name="nbf" value="<?= $data[0]["nbf"]; ?>">
				</td>
				<td class="w20">
					<select name="jenis_faktor">
						<option value="<?= $data[0]["jenis_faktor"]; ?>">- <?= $data[0]["jenis_faktor"]; ?> -</option>
						<option value="cost">Cost</option>
						<option value="benefit">Benefit</option>
					</select>
				</td>
				<td>
					<div class="submit">
						<button name="submit">
							<!-- <i class="fa fa-plus" aria-hidden="true"></i>  -->Save
						</button>
					</div>
				</td>
			</tr>
		</table>
		<table class="w100">
			<tr>
				
			</tr>
		</table>
	</form>
	<?php 
		if ( isset($_POST["submit"]) ) {
			// echo "Lakukan proses";
			// var_dump($_POST);
				if ( edit_faktor($_POST) > 0  ) {
					?> 
					<script>
						alert("Berhasil");
						window.location.href="?hl=fktr&op=show";
					</script>
					<?php 
				} else {
					echo mysqli_error($db);
				}
		}
	?>
</div>