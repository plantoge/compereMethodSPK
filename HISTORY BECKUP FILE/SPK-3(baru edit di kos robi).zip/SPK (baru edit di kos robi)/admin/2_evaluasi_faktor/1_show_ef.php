<div class="show">
	<div class="judul">
		<h3>Data Evaluasi Siswa</h3>
		<h5 style="font-weight: normal; margin-top: -10px;">
			note : Data Evaluasi Faktor atau Atribut
		</h5>
	</div>
	<div class="button">
		<a href="?hl=ef&op=input">
			<button>
				<i class="fa fa-plus" aria-hidden="true"></i>
			</button>
		</a>
	</div>

	<div class="form">
		<form method="post">
			<table class="w100 border" border="1">
				<tr>
					<th>No.</th>
					<th>No.</th>
					<th>No.</th>
					<th>No.</th>
				</tr>
				<?php ?>
				<tr>
					<td>a</td>
					<td>a</td>
					<td>a</td>
					<td>a</td>
				</tr>
				<?php ?>
			</table>
		</form>
	</div>
</div>