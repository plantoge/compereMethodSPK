<div class="bg_ev_faktor">
	<div class="judul txtcenter">
		<h3>Create Data Evaluasi Siswa</h3>
		<hr>
	</div>
	<form method="POST">
		<table>
		<?php 
		// for ($i=1; $i <= 2; $i++) { 
		?>
			<tr>
				<td>
					<input type="text" name="nisn" placeholder="Nomor Induk Siswa">
				</td>
			</tr>
			<tr>
				<td>
					<input type="text" name="nama_siswa" placeholder="Nama Siswa">
				</td>
			</tr>
			<?php 
				$no = 1;
				foreach ($data as $nama_faktor) {
			?>
					<tr>
						<td>
							<input type="text" name="nilai_f<?= $no++; ?>" placeholder="<?= $nama_faktor['nama_faktor']; ?>">
						</td>
					</tr>
			<?php 
				}
		// }
			?>
			<tr>
				<td>
					<input type="submit" name="submit" value="Save">
				</td>
			</tr>
		</table>
	</form>
<?php 
		if ( isset($_POST["submit"]) ) {
			if ($hasil1['jml_faktor'] == 5) {
				if ( tambah_ef($_POST) > 0  ) {
					?> 
					<script>
						alert("Berhasil ditambahkan");
						// window.location.href="?hl=ef&op=show";
					</script>
					<?php 
				} else {
					echo mysqli_error($db);
				}
			} else {
				?> 
				<script>
					alert("Data Faktor tidak Mencukupi Batas Maksimal");
					window.location.href="?hl=ef&op=show";
				</script>
				<?php
			}
		}
?>
</div>
