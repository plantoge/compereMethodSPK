<div class="error_data_user">
	<h2>Opps..!! Anda Tidak Ada Hak Untuk Mengakses Halaman ini</h2>
</div>