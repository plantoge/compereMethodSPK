CREATE TABLE f1_kfaktor (
	inisial varchar(2) PRIMARY KEY,
	nama_kfaktor varchar(50),
	atribut_kfaktor enum('C','B'),
	nbf float
);
