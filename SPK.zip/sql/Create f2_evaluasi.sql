CREATE TABLE f2_evaluasi (
	nisn varchar(9) PRIMARY KEY,
	nama_siswa varchar(50),
	hasil_mfep float,
	hasil_saw float
);