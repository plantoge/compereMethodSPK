<!DOCTYPE html>
<html>
<head>
	<title>Data Kriteria</title>
	<link rel="stylesheet" type="text/css" href="../style/style_report.css">
	<link rel="stylesheet" type="text/css" href="../style/responsif.css">
</head>
<body>
	<div class="header border">
		<table class="w100">
			<tr>
				<td class="w10 kiri border">
					<img src="../gambar/twh.png" width="100" height="100">
				</td>
				<td class="w80 tengah border">
					<p align="center">a</p>
				</td>
				<td class="w10 kanan border">
					<img src="../gambar/twh.png" width="100" height="100" style="float: right;">
				</td>
			</tr>
		</table>
	</div>

</body>
</html>